package com.example.webviewsatu;

import com.journeyapps.barcodescanner.CaptureActivity;

public class CapturreAct extends CaptureActivity {

}