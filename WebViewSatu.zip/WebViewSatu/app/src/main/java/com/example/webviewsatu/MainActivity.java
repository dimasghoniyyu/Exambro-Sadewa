package com.example.webviewsatu;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends AppCompatActivity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("https://docs.google.com/forms/d/e/1FAIpQLSeefgY2ns41nQtr6RvW-S-FtIBVKIOHpzb8IWABpK6GXUVemQ/viewform?usp=sf_link");

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        super.onCreate(savedInstanceState);


    }

    int counter = 0;
    @Override
    public void onBackPressed() {
        counter++;
        if (counter == 12)
        super.onBackPressed();
    }

    @Override
    public void onPause(){
        super.onPause();
        ActivityManager activityManager = (ActivityManager) getApplicationContext()
                .getSystemService(Context.ACTIVITY_SERVICE);
        activityManager.moveTaskToFront(getTaskId(), 0);

    }



    @Override
    public void onStop(){
        counter++;
        if (counter == 12)
            super.onStop();

    }



}


//int id = 0;
//public void onBackPressed() {
//  AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
//alertDialogBuilder.setTitle("Keluar");
//alertDialogBuilder.setMessage("Yakin keluar dari aplikasi ?").setCancelable(false).setPositiveButton("Ya", new DialogInterface.OnClickListener() {
//  public void onClick(DialogInterface dialog, int id ) {
//    id++;
//  System.exit(5);
// super.onBackPressed();
// }
// }).setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
//   public void onClick(DialogInterface dialog, int id) {
//     dialog.cancel();
//}
//});
// alertDialogBuilder.create().show();
//}
